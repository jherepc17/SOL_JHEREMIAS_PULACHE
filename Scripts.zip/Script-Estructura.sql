create table LIBROS
(
    ID_LIBRO          NUMBER generated as identity
        constraint SYS_C007479
            primary key,
    NOMBRE            VARCHAR2(100) not null,
    CATEGORIA         VARCHAR2(50)  not null,
    AUTOR             VARCHAR2(100) not null,
    PAIS              VARCHAR2(50)  not null,
    FECHA_PUBLICACION DATE          not null,
    EDITORIAL         VARCHAR2(100) not null
)
/

create table TIPOUSUARIO
(
    ID_TIPOUSUARIO NUMBER generated as identity
        constraint SYS_C007491
            primary key,
    NOMBRE         VARCHAR2(20) not null
)
/

create table USUARIOS
(
    ID_USUARIO     NUMBER     generated as identity
        constraint SYS_C007471
        primary key,
    DNI            VARCHAR2(20)  not null,
    NOMBRES        VARCHAR2(50)  not null,
    APELLIDOS      VARCHAR2(50)  not null,
    EMAIL          VARCHAR2(100) not null,
    TELEFONO       VARCHAR2(20)  not null,
    ESTADO         NUMBER(1) default 1
        constraint SYS_C007470
            check (Estado IN (0, 1)),
    ID_TIPOUSUARIO NUMBER(10)    not null
        constraint SYS_C007493
            references TIPOUSUARIO
)
/

create table TIPOSPRESTAMO
(
    ID_TIPOPRESTAMO NUMBER generated as identity
        constraint SYS_C007496
            primary key,
    NOMBRE          VARCHAR2(100) not null
)
/

create table PRESTAMOS
(
    ID_PRESTAMO      NUMBER generated as identity
        constraint SYS_C007486
            primary key,
    ID_LIBRO         NUMBER(10) not null
        constraint SYS_C007487
            references LIBROS,
    ID_USUARIO       NUMBER(10) not null
        constraint SYS_C007488
            references USUARIOS,
    FECHA_PRESTAMO   DATE       not null,
    FECHA_DEVOLUCION DATE,
    ID_TIPO_PRESTAMO NUMBER     not null
        constraint "PRESTAMOS_TIPOSPRESTAMO_ID_TIPOPRESTAMO_fk"
            references TIPOSPRESTAMO
)
/