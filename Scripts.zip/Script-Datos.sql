INSERT INTO TIPOUSUARIO (NOMBRE) VALUES ('Docente')
/
INSERT INTO TIPOUSUARIO (NOMBRE) VALUES ('Alumno');
/


INSERT INTO TIPOSPRESTAMO (NOMBRE) VALUES ('Lectura en biblioteca');
/
INSERT INTO TIPOSPRESTAMO (NOMBRE) VALUES ('Retiro a casa');
/


INSERT INTO USUARIOS (DNI, NOMBRES, APELLIDOS, EMAIL, TELEFONO, ESTADO, ID_TIPOUSUARIO) VALUES ('11111111A', 'Juan', 'Pérez', 'juan.perez@email.com', '123456789', 1, 1);
/
INSERT INTO USUARIOS (DNI, NOMBRES, APELLIDOS, EMAIL, TELEFONO, ESTADO, ID_TIPOUSUARIO) VALUES ('22222222B', 'María', 'López', 'maria.lopez@email.com', '987654321', 1, 1);
/
INSERT INTO USUARIOS (DNI, NOMBRES, APELLIDOS, EMAIL, TELEFONO, ESTADO, ID_TIPOUSUARIO) VALUES ('33333333C', 'Pedro', 'García', 'pedro.garcia@email.com', '654321987', 1, 2);
/
INSERT INTO USUARIOS (DNI, NOMBRES, APELLIDOS, EMAIL, TELEFONO, ESTADO, ID_TIPOUSUARIO) VALUES ('44444444D', 'Ana', 'Rodríguez', 'ana.rodriguez@email.com', '159753246', 1, 2);



INSERT INTO LIBROS (NOMBRE, CATEGORIA, AUTOR, PAIS, FECHA_PUBLICACION, EDITORIAL) VALUES ('Cien años de soledad', 'Realismo mágico', 'Gabriel García Márquez', 'Colombia', DATE '1967-05-30', 'Sudamericana');
/
INSERT INTO LIBROS (NOMBRE, CATEGORIA, AUTOR, PAIS, FECHA_PUBLICACION, EDITORIAL) VALUES ('El amor en los tiempos del cólera', 'Romance', 'Gabriel García Márquez', 'Colombia', DATE '1985-10-16', 'Oveja Negra');
/
INSERT INTO LIBROS (NOMBRE, CATEGORIA, AUTOR, PAIS, FECHA_PUBLICACION, EDITORIAL) VALUES ('1984', 'Ciencia ficción', 'George Orwell', 'Reino Unido', DATE '1949-06-08', 'Secker & Warburg');
/
INSERT INTO LIBROS (NOMBRE, CATEGORIA, AUTOR, PAIS, FECHA_PUBLICACION, EDITORIAL) VALUES ('El señor de los anillos', 'Fantasía', 'J.R.R. Tolkien', 'Reino Unido', DATE '1994-07-29', 'Allen & Unwin');
/
INSERT INTO LIBROS (NOMBRE, CATEGORIA, AUTOR, PAIS, FECHA_PUBLICACION, EDITORIAL) VALUES ('El código Da Vinci', 'Thriller', 'Dan Brown', 'Estados Unidos', DATE '2003-03-18', 'Doubleday');
/
INSERT INTO LIBROS (NOMBRE, CATEGORIA, AUTOR, PAIS, FECHA_PUBLICACION, EDITORIAL) VALUES ('La sombra del viento', 'Novela histórica', 'Carlos Ruiz Zafón', 'España', DATE '2001-01-01', 'Planeta');
/